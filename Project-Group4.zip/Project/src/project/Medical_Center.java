/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author shahadaleissa
 */
public class Medical_Center {

    public Medical_Center() {
    }

    public Medical_Center(String medId, String centerName, String location) {
        this.medId = medId;
        this.centerName = centerName;
        this.location = location;
    }

    
    
    private String medId;
    private String centerName;
    private String location;
  
    
}
